chrome.runtime.onInstalled.addListener(() => {
    console.log("La extensión ha sido instalada.");
});
