document.getElementById('submit').addEventListener('click', function() {
    const password = document.getElementById('password').value;
    if (password === 'beta') {
        document.getElementById('accessLink').style.display = 'inline-block'; // Muestra el enlace
        document.getElementById('password').value = ''; // Limpiar el campo de contraseña
    } else {
        alert('Contraseña incorrecta. Inténtalo de nuevo.');
    }
});
